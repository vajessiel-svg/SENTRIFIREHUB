"""SentriFire Raspberry Pi backend package."""

__version__ = "2.0.0"
